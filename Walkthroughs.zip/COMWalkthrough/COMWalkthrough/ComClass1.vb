﻿<ComClass(ComClass1.ClassId, ComClass1.InterfaceId, ComClass1.EventsId)>
Public Class ComClass1
    Public Const ClassId As String = "62860F30-A249-4710-8EC4-C62B6FCF588F"
    Public Const InterfaceId As String = "6F62713F-E3B2-4594-9B6F-DC74228DA0BB"
    Public Const EventsId As String = "D3736626-0D63-466E-9CBC-4319F7ED53F1"

    Public Sub New()
        MyBase.New()
    End Sub

End Class
